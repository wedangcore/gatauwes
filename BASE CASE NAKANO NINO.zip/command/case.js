//=========================================================
// MODULE
const fs = require('fs');
const path = require('path');
const util = require('util');
const chalk = require('chalk');
const { exec, execSync, spawn } = require("child_process");
//=========================================================

//=========================================================
require('@config/mess')
require('@config/media')
require('@config/setting')
const { getGroupAdmins, parseMention, runtime, decodeJid, litespace, logMessage, getRandomThumbnail } = require('@lib/library');
//=========================================================

//=========================================================
// ============== BACA DB JSON
const readJSON = (path) => JSON.parse(fs.readFileSync(require.resolve(path), 'utf-8'));
const premium = readJSON('@role/premium.json');
const userbot = readJSON('@role/user.json');
//=========================================================

//=========================================================
module.exports = wbk = async (wbk, m, msg, chatUpdate, store) => {
//=========================================================
   
//=========================================================
try {
    const { type, quotedMsg, mentioned, now, fromMe } = m
    const body = m.body || '';
    const budy = m.text || '';
    const prefix = /^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/gi) : prefa;
    const isCmd = prefix ? body.startsWith(prefix) : false;
    const isCommand = isCmd ? body.slice(1).trim().split(' ').shift().toLowerCase() : ""
    const command = isCmd ? body.slice(1).trim().split(' ').shift().toLowerCase() : ''
    const args = body.trim().split(/ +/).slice(1);
    const botNumber = await decodeJid(wbk.user.id);
    const text = q = args.join(" ");
    const getQuoted = (m.quoted || m);
    const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
    const mime = (quoted.msg || quoted).mimetype || '';
    const isGroup = m.key.remoteJid.endsWith('@g.us');
    const isPrivate = !isGroup;
    const groupMetadata = m.isGroup ? await wbk.groupMetadata(m.chat).catch(e => {}) : ''
    const groupName = m.isGroup ? groupMetadata?.subject : ''
    const participants = m.isGroup ? await groupMetadata?.participants : ''
    const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
    const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    const groupOwner = m.isGroup ? groupMetadata.owner : ''
    const isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false
    const clientId = wbk.user.id.split(':')[0];
    const senderbot = m.key.fromMe ? wbk.user.id.split(':')[0] + "@s.whatsapp.net" || wbk.user.id : m.key.participant || m.key.remoteJid;
    const senderId = senderbot.split('@')[0];
    const isBot = clientId.includes(senderId);
    const isUser = userbot.includes(m.sender);
    const isCreator = [botNumber, global.ownerNumber].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
//=========================================================
    
//=========================================================
// ============== DATABASE
    try {
        let user = db.data.users[m.sender] || {};
        if (typeof user !== "object") db.data.users[m.sender] = {};
        if (!("name" in user)) user.nama = "User";
        if (!("age" in user)) user.age = 0;
        if (!("city" in user)) user.city = "Jember";
        db.data.users[m.sender] = user;
    } catch (error) {
        console.error("⚠️ Terjadi kesalahan:", error);
    }
//=========================================================
    
//=========================================================
// ============== CONSOLE LOG
    if (m.message) {
        let title = chalk.white(chalk.bgHex("#4a69bd").bold("🚀  There is a message  🚀"));
        let sender = chalk.yellowBright(`${"🗣️  Sender Name".padEnd(21)} : ${m.pushName || botName}`);
        let jid = chalk.magentaBright(`${"👤  ID Sender".padEnd(20)} : ${m.sender}`);
        let chat = chalk.whiteBright(`${"💬  Chat".padEnd(20)} : ${m.text}`);
        let group = chalk.redBright(`${"🔍  Group".padEnd(20)} : ${groupName}`);
        let line = chalk.white("------------------------------------------")
        if (isCmd && !m.isGroup) {
            console.log(title);
            console.log(sender);
            console.log(jid);
            console.log(chat);
            console.log(line);
        } else if (m.isGroup) {
            console.log(title);
            console.log(sender);
            console.log(jid);
            console.log(group);
            console.log(chat);
            console.log(line);
        }
    }
//=========================================================
    
//=========================================================
// ============== REPLY
    global.reply = async function (teks) {
        const nakanonino = getRandomThumbnail()
        wbk.sendMessage(m.chat, {
            contextInfo: {
                mentionedJid: parseMention(teks),
                externalAdReply: {
                    title: wm,
                    body: desc,
                    thumbnail: nakanonino,
                    sourceUrl: global.website,
                    mediaType: 1,
                }
            },
            text: teks,
        }, { quoted: m });
    }
//=========================================================
    
//=========================================================
switch (command) {
//=========================================================


case "self": {
    if (!isCreator) return reply(global.mess.owner);
    wbk.public = false;
    reply(`Bot sekarang dalam mode *Self Usage* aja, jadi gak bisa dipakai oleh orang lain ya!`);
}
break;

case "public": {
    if (!isCreator) return reply(global.mess.owner);
    wbk.public = true;
    reply(`Bot sekarang kembali ke mode *Public Usage*, jadi bisa dipakai semua orang!`);
}
break;
        

//=========================================================
default:
//=========================================================

if (budy.startsWith('=>')) {
	if (!isCreator) return m.react('⚠️');
	if (isBot) return m.react('⚠️');
	await m.react('⏱️');
	function Return(sul) {
		sat = JSON.stringify(sul, null, 2)
		bang = util.format(sat)
		if (sat == undefined) {
			bang = util.format(sul)
		}
		m.react('✅');
		return m.reply(bang)
	}
	try {
		m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
	} catch (e) {
		m.reply(String(e))
	}
};

if (budy.startsWith('>')) {
	if (!isCreator) return m.react('⚠️');
	if (isBot) return m.react('⚠️');
	try {
		await m.react('⏱️');
		let evaled = await eval(budy.slice(2))
		if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
		m.react('✅');
		await m.reply(evaled)
	} catch (err) {
		await m.reply(String(err))
	}
};

if (budy.startsWith('$')) {
	if (!isCreator) return m.react('⚠️');
	if (isBot) return m.react('⚠️');
	await m.react('⏱️');
	exec(budy.slice(2), (err, stdout) => {
		m.react('✅');
		if (err) return m.reply(err)
		if (stdout) return m.reply(stdout)
	})
};    

}
} catch (err) {
    logMessage("🔴  Error on Case 🔴", `${util.format(err)}`)
}
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    logMessage("🆙  Update  🆙", `${__filename}`)
    delete require.cache[file];
    require(file);
});