const fs = require('fs');
const { logMessage } = require('@lib/library')

//=========================================================
// BOT
global.botName = 'Nakano Nino';
global.desc = '~Anata no koto o motto shiritai…';
global.ownerName = 'WBK';
global.ownerNumber = '6285183134846';
global.creator = '6285183134846@s.whatsapp.net';
global.location = '11 Naitōmachi, Shinjuku City, Tokyo 160-0014, Jepang';
global.packname = '';
global.author = 'Nakano Nino - 覚悟しなさいよ！\n~ Kakugo shinasai yo!\n\n\n©WBK';
global.wm = 'Nakano Nino | WBK';
global.footer = 'Nakano Nino - 覚悟しなさいよ！';
//=========================================================

//=========================================================
// PREFIX, DLL
global.prefa = '#', '.', '!';
global.public = true;
//=========================================================

// ========================================================
global.sosmed = {
    email: "wbagazk@gmail.com",
    yt: "",
    ig: "",
    tt: "",
    gh: "https://github.com/wbagazk",
    website: "https://wbagazk.my.id",
    gcwa: "https://chat.whatsapp.com/0",
    chwa: "https://whatsapp.com/channel/0",
    idgcwa: "0@g.us",
    idchwa: "0@newsletter",
};
// ========================================================

//=========================================================
// LIMIT DAN UANG
global.limit = {
	free: 20, // Limit User Non-premium
	premium: 999, // Limit User Premium
};
global.point = {
	free: 10000, // Uang User Non-premium
	premium: 100000, // Uang User Premium
};
global.bot = {
	limit: 0, // Limit Awal Bot
	uang: 0 // Uang Awal Bot
};
//=========================================================

//=========================================================
// NOTif CONSOLE
let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    logMessage("🆙  Update  🆙", `${__filename}`)
    delete require.cache[file];
    require(file);
});